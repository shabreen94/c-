﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    class Program
    {
        static void Main(string[] args)
        {
            DisplayMenu();
            int choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    Rectangle re = new Rectangle();
                    re.SetValues();
                    re.area();
                    break;
                case 2:
                    Triangle t = new Triangle();
                    t.SetValues();
                    t.area();
                    break;
                
            }


        }

        static void  DisplayMenu()
        {
            Console.WriteLine("Choose the diahgrams");
            string[] menu =
            {
                "1.Rectangle",
                "2.Traingle"
            };
            for (int i = 0; i < menu.Length; i++)
            {
                Console.WriteLine(menu[i]);
            }

           

        }


    }

    class Shape
    {
        public double length;
        public double breadth;
        public void SetValues()
        {
            Console.WriteLine("Enter the length value");
            length = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the breadth value");
            breadth = Convert.ToDouble(Console.ReadLine());

        }
        public virtual void area()
        {
            Console.WriteLine("The area is computed");

        }
    }

    class Rectangle : Shape
    {
        double areaofrect;
        public override void area()
        {
            areaofrect = length * breadth;
            Console.WriteLine("The area of the rectangle is "+ areaofrect);
            Console.ReadLine();
        }
    }

    class Triangle : Shape
    {
        double areaoftri;
        public override void area()
        {
            areaoftri = (0.5) * length * breadth;
            Console.WriteLine("The area of the triangle is "+ areaoftri);
            Console.ReadLine();
        }
    }

}
