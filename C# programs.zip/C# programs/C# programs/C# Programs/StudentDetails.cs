﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentDetails
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter the number of students");
            int noofstu = Convert.ToInt32(Console.ReadLine());
            List<Student> students = new List<Student>(noofstu) ;
            int[] sum = new int[noofstu];
            for (int i = 0; i < noofstu; i++)
            {
                Student s = new Student();
                s.Id = getDetails("Enter the student  ID");
                s.Pmarks = getDetails("Enter the student   Physics marks");
                s.Cmarks = getDetails("Enter the student  Chemistry marks");
                s.Mmarks = getDetails("Enter the student   Maths marks");
                s.Bmarks = getDetails("Enter the student   Biology marks");
                students.Add(s);
            }
       
            Displaymenu();
            Console.Clear();
            Console.WriteLine("Enter the choice of operation");
            int choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    foreach (var item in students)
                    {
                        for (int i = 0; i < noofstu; i++)
                        {
                            sum[i] = (item.Bmarks + item.Cmarks + item.Mmarks + item.Pmarks);
                            Console.WriteLine("The sum of marks of student {0} is {1}", item.Id, sum[i]);
                            Console.ReadLine();
                        }
                    }
                    break;
                case 2:
                    Idofmaxscored(students);
                    break;
                case 3:
                    highestoftotal(sum);
                    break;

                case 4:
                    top5(students);
                    break;
                case 5:
                    Despcb(students);
                    break;
            }
        }


        static void Despcb(List<Student> students)
        {

            int temp = 0;
            int[] sum = new int[students.Count];

            for (int i = 0; i < students.Count; i++)
            {
               sum[i] = students[i].Pmarks + students[i].Cmarks + students[i].Cmarks;
            }
            for (int i = 0; i < students.Count; i++)
                for (int j = i + 1; j < students.Count; j++)
                {
                    if (sum[i]< sum[j])
                    {
                        temp = sum[i];
                       sum[i] = sum[j];
                        sum[j] = temp;
                    }
                }

            for (int i = 0; i < students.Count; i++)
            {
                Console.WriteLine($"The total marks in descending order in physics chemistry and biology is {sum[i]}");
            }
        }

        /*to list the top5 students based on thne Chemistry ,maths,physics
         */

            static void top5(List<Student> students)
            {

            int temp = 0;
            for (int i = 0; i < students.Count; i++)
            {
                for (int j = i + 1; j < students.Count; j++)
                {
                    if (students[i].Pmarks < students[j].Pmarks)
                    {
                        temp = students[i].Pmarks;
                        students[i].Pmarks = students[j].Pmarks;
                        students[j].Pmarks = temp;
                    }
                }
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"The top 5 students in physics are {students[i].Pmarks}");
            }

            for (int i = 0; i < students.Count; i++)
            {
                for (int j = i + 1; j < students.Count; j++)
                {
                    if (students[i].Cmarks < students[j].Cmarks)
                    {
                        temp = students[i].Cmarks;
                        students[i].Cmarks = students[j].Cmarks;
                        students[j].Cmarks = temp;
                    }
                }
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"The top 5 students in chemistry are {students[i].Cmarks}");
            }

            for (int i = 0; i < students.Count; i++)
            {
                for (int j = i + 1; j < students.Count; j++)
                {
                    if (students[i].Mmarks < students[j].Mmarks)
                    {
                        temp = students[i].Mmarks;
                        students[i].Mmarks = students[j].Mmarks;
                        students[j].Mmarks = temp;
                    }
                }
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"The top 5 students in maths are {students[i].Mmarks}");
            }

        }

        /*To display the highest total marks student
         */

        private static void highestoftotal(int[] sum)
        {
            int max = 0;
            int id = 0;
            for (int i = 0; i < sum.Length; i++)
            {
                if (max < sum[i])
                {
                    max = sum[i];
                    id = i;
                }
            }

            Console.WriteLine("The highest total marks {0} scored by student {1}", max, id);
        }

        /* To display the student who scored max in each subject

        */
        private static void Idofmaxscored(List<Student> students)
        {
            int maxid = 0;
            int pmax = 0;
            int cmax = 0;
            int bmax = 0;
            int mamax = 0;

            //Physics marks
            for (int i = 0; i < students.Count; i++)
            {
                if (pmax < students[i].Pmarks)
                {
                    pmax = students[i].Pmarks;
                    maxid = students[i].Id;

                }

            }
            Console.WriteLine("The student who scored highest marks in physics id {0}", maxid);

            // Chemistry marks

            for (int i = 0; i < students.Count; i++)
            {
                if (cmax < students[i].Cmarks)
                {
                    cmax = students[i].Cmarks;
                    maxid = students[i].Id;

                }

            }
            Console.WriteLine("The student who scored highest marks in physics id {0}", maxid);

            // Biology marks

            for (int i = 0; i < students.Count; i++)
            {
                if (bmax < students[i].Bmarks)
                {
                    bmax = students[i].Bmarks;
                    maxid = students[i].Id;

                }

            }
            Console.WriteLine("The student who scored highest marks in Biology id {0}", maxid);

            // Maths marks

            for (int i = 0; i < students.Count; i++)
            {
                if (mamax < students[i].Mmarks)
                {
                    mamax = students[i].Mmarks;
                    maxid = students[i].Id;

                }

            }
            Console.WriteLine("The student who scored highest marks in Maths id {0}", maxid);
        }

        //To get the details of the students
        
        static int getDetails(string message)
        {
            Console.WriteLine(message);
            return Convert.ToInt32(Console.ReadLine());
        }

        // To display menu options

        static  void Displaymenu()
        {
            string[] array = 
            {
                "1.Total marks obtained by each student",
                "2.The highest marks obtained in each subject and the Roll No. of the student who secured it",
                "3.The student who secured highest total marks",
                "4.The Top 5 students who secured highest marks in Physics, Chemistry and Mathematics",
                "5. The list of students in descending order of total marks scored in Physics, Chemistry and Biology"
            };
            for (int i = 0; i <array.Length; i++)
            {
                Console.WriteLine(array[i]);
            }
        }
     
    }

    class Student
    {
        public int Id;
        public int Pmarks;
        public int Cmarks;
        public int Mmarks;
        public int Bmarks;
    }
}



