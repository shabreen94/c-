﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    //class MultidimensionalArrays
    //{
    //    static void Main(string[] args)
    //    {
    //        int[,] array= new int[3, 3];

    //        for (int i = 0; i < array.GetLength(0); i++)
    //        {
    //            for (int j = 0; j < array.GetLength(1); j++)
    //            {
    //                array[i, j] = j * 3 + i;
    //                Console.WriteLine(array[i, j]);
    //            }
    //        }
    //        Console.ReadLine();
    //    }
    //}

    class JagArrays
    {
        public static void Main(string[] args)
        {

            int[][] array = new int[3][];
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = new int[3];
                for (int j = 0; j < array[i].Length; j++)
                {

                    array[i][j] = i * 3 * 4 + j;
                    Console.WriteLine(array[i][j] + '\t');
                    
                }
                Console.WriteLine('\n');
            }
            Console.ReadLine();


        }
    }


    //Inner arrays are of diiferent sizes

    //class JagArrays
    //{
    //    public static void Main(string[] args)
    //    {

    //        int[][] array = new int[3][];

    //        array[0] = new int[2];
    //        for (int j = 0; j < array[0].Length; j++)
    //        {
    //            array[0][j] = j * 5 + 5;
    //            Console.WriteLine(array[0][j]);
    //        }

    //        array[1] = new int[5];
    //        for (int j = 0; j < array[1].Length; j++)
    //        {
    //            array[1][j] = j * 4 + 6;
    //            Console.WriteLine(array[1][j]);
    //        }

    //        array[2] = new int[4];
    //        for (int j = 0; j < array[2].Length; j++)
    //        {

    //            array[2][j] = j * 4 + 10;
    //            Console.WriteLine(array[2][j]);

    //        }
    //        Console.ReadLine();


    //    }
//}









}
