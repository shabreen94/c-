﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Threading
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("mian method started...");
            longmethod();

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Main method is executed - {i} times");
            }
            Console.WriteLine("main method is endeed");
            Console.ReadLine();
        }

        static void longmethod()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Long method is executed - {i} times");
            }
            Console.WriteLine("main method is endeed");
            Console.ReadLine();
        }
    }
}
