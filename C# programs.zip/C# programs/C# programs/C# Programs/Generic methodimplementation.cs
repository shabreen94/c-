﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Genericmethodimplementation
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             As we are creating the objects of var type t.GetType() will give u the exact type of object
             */

            var e1 = new Employee { id = "e1", name = "harika", company = "TechM" };
            var m1 = new Manager { id = "m1", name = "lakshmi", company = "TechM", numofsubordinates = 10 };

            //Employee e1 = new Employee { id = "e1", name = "harika", company = "TechM" };
            //Manager m1 = new Manager { id = "m1", name = "lakshmi", company = "TechM", numofsubordinates = 10 };
            int[] i = { };

            details(e1);
            details(m1);
            details(i);
        }

        static void details<T>(T t)
        {
            Console.WriteLine(t);
            Console.WriteLine("hello {0}", t.GetType());
            Console.ReadLine();

        }
    }


    class Employee
    {
        public string id;
        public string name;
        public string company;
    }

    class Manager
    {
        public string id;
        public string name;
        public string company;
        public int numofsubordinates;
    }



}
