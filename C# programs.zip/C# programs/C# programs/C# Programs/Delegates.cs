﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// to use delegate tocall the functions and to pass fuction as aparametr to other functions
// Here we send the static methods as a parameter to the argument 
//We can send the instance methods also as a parameter to the function

namespace Delegates
{
    delegate int Mydelegate(int i, int j);
    class Program
    {
        static void Main()
        {
            while (true)
            {
                DisplayMenu();
                Console.WriteLine("Enter the choice");
                int ch = Convert.ToInt32(Console.ReadLine());
                int i = 6;
                int j = 5;
                //int res = 0; 
                Mydelegate del = null;

                switch (ch)
                {
                    case 1:
                        del += Sum;
                        del(5, 6);
                        //sending the values for he parameters
                        break;
                    case 2:
                        del = Sub;
                        del(7, 5);//sending the values for he parameters

                        break;
                    case 3:
                        del = Mul;
                        del(5, 4);//sending the values for he parameters

                        break;
                    case 4:
                        del = Div;
                        del(2, 1);//sending the values for he parameters

                        break;
                    case 5:
                        del = Sum;
                        del += Sub;
                        del += Mul;
                        del += Div;
                       // del(i, j);
                        Display(del);
                        Func<string, string> delegatefunc = details;
                        delegatefunc("Hi harika this is delegate func");
                        break;
                }
            }
            Console.ReadLine();

        }

        private static string details(string message)
        {

            Console.WriteLine(message);
            Console.ReadLine();
        }
       

        private static int Sum(int i, int j)
        {
            Console.WriteLine("THe sum is " + i + j);
            return i + j;
        }

        private static int Sub(int i,int j)
        {
            Console.WriteLine("THe sub is " + (i - j));
            return i - j;
        }
        private static int Mul(int i, int j)
        {
            Console.WriteLine("THe mul is " +( i * j));
            return i * j;
        }
        private static int Div(int i, int j)
        {
            Console.WriteLine("THe div is " + (i / j));
            return i / j;
        }

        static  void DisplayMenu() {

            Console.WriteLine("1.Add");
            Console.WriteLine("2.Sub");
            Console.WriteLine("3.Mul");
            Console.WriteLine("4.Div");
            Console.WriteLine("5.All");
        }

        static void Display(Mydelegate ope) {
            Console.WriteLine("All operations are performed");
            ope(5, 6);
            Console.WriteLine("The callbak function is performed");
        } 

    }
}
