﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class SortTest
    {
        delegate void Mydelegate(int[] array, int ch);
        static void Main(string[] args)
        {
            Stopwatch sp = new Stopwatch();
            Console.WriteLine("Enter the array size");
            int size = Convert.ToInt32(Console.ReadLine());
            int[] array = new int[size];
            Console.WriteLine("Enter the array values");
            int looping = 1;
            Mydelegate del = null;

            /*Using same for loop to read the data as well as to write the data based on looping
             * if looping =1 then read the data and if the looping =2 then write the data
             */


            //sp.Start();
            //while (looping < 3)
            //{
            //    for (int i = 0; i < size; i++)
            //    {
            //        if (looping == 1)
            //            array[i] = Convert.ToInt32(Console.ReadLine());
            //        else
            //        {
            //            Console.WriteLine("The array elements are" + array[i]);

            //        }
            //    }
            //    Console.ReadLine();
            //    looping++;
            //}
            //sp.Stop();

            //TimeSpan ts = sp.Elapsed;
            //Console.WriteLine("The time taken to read and print the array details through looping " + ts);

            sp.Start();
            for (int i = 0; i < size; i++)
            {
                array[i] = Convert.ToInt32(Console.ReadLine());
            }

            for (int i = 0; i < size; i++)
            {
                Console.WriteLine("The array elements are" + array[i]);
            }
            sp.Stop();
            TimeSpan ts2 = sp.Elapsed;
            Console.WriteLine("The time taken to read and print the array details through two for loops " + ts2);


            Displaymenu();
            Console.WriteLine("Enter the choice of operation");
            int choice = Convert.ToInt32(Console.ReadLine());

            Bubblesort b = new Bubblesort();
            Selectionsort s = new Selectionsort();
            InsertionSort ins = new InsertionSort();

            //Multicast delegates or Delegate chaining

            del = b.bubblesort;
            del += s.selectionsort;
            del += ins.insertionsort;
            del(array, choice);

        }

        static void Displaymenu()
        {
            string[] menu =
                {
                     "1.Ascending order",
                     "2.Descending order"
                  };

            for (int i = 0; i < menu.Length; i++)
            {
                Console.WriteLine(menu[i]);
            }
        }
    }

    class Bubblesort
    {
        int count = 0;
        public void bubblesort(int[] array, int choice)
        {
            Stopwatch sp = new Stopwatch();
            sp.Start();
            if (choice == 1)
            {
                for (int j = 0; j <= array.Length - 2; j++)
                {
                    for (int i = 0; i <= array.Length - 2; i++)
                    {

                        if (array[i] > array[i + 1])
                        {
                            int t = array[i + 1];
                            array[i + 1] = array[i];
                            array[i] = t;
                        }
                        count++;
                    }
                }
            }

            else
            {
                for (int i = 0; i < array.Length; i++)
                {
                    for (int j = 1; j < (array.Length - i); j++)
                    {
                        if (array[j - 1] < array[j])
                        {
                            //swap the elements!
                            int t = array[j - 1];
                            array[j - 1] = array[j];
                            array[j] = t;
                        }
                        count++;
                    }
                }
            }

            sp.Stop();
            TimeSpan ts = sp.Elapsed;
            Console.WriteLine("Sorted array by using bubble sort algorithm");
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i]);

            }
            Console.WriteLine("The count of operationsin bubble sort  is" + count);
            Console.WriteLine(ts);
        }
    }

    class Selectionsort
    {
        int count = 0;
        int temp, min_key;
        public void selectionsort(int[] array, int choice)
        {
            Stopwatch sp = new Stopwatch();
            sp.Start();
            if (choice == 1)
            {
                for (int j = 0; j < array.Length - 1; j++)
                {
                    min_key = j;

                    for (int k = j + 1; k < array.Length; k++)
                    {
                        if (array[k] < array[min_key])
                        {
                            min_key = k;
                        }
                    }
                    count++;

                    temp = array[min_key];
                    array[min_key] = array[j];
                    array[j] = temp;
                }
            }

            else
            {
                int first;
                for (int i = array.Length - 1; i > 0; i--)
                {
                    first = 0;
                    for (int j = 1; j <= i; j++)
                    {
                        if (array[j] < array[first])
                            first = j;
                    }
                    count++;
                    temp = array[first];
                    array[first] = array[i];
                    array[i] = temp;
                }
            }
            sp.Stop();
            TimeSpan ts = sp.Elapsed;
            Console.WriteLine("Sorted array by using selection sort algorithm");
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i]);

            }
            Console.WriteLine("The count of operations in selection sort is" + count);
            Console.WriteLine(ts);
        }
    }

    class InsertionSort
    {
        int count = 0;

        public void insertionsort(int[] array, int choice)
        {
            Stopwatch sp = new Stopwatch();
            sp.Start();
            if (choice == 1)
            {
                for (int i = 1; i < array.Length; i++)
                {
                    int item = array[i];
                    int ins = 0;
                    for (int j = i - 1; j >= 0 && ins != 1;)
                    {
                        if (item < array[j])
                        {
                            array[j + 1] = array[j];
                            j--;
                            array[j + 1] = item;
                        }
                        else ins = 1;
                    }
                    count++;
                }
            }
            else
            {
                for (int j = 1; j < array.Length; j++)
                {

                    int key = array[j];

                    int i = j - 1;

                    while (i > 0 && array[i] < key)
                    {
                        array[i + 1] = array[i];
                        i = i - 1;
                        array[i + 1] = key;
                    }
                    count++;
                }
            }

            sp.Stop();
            TimeSpan ts = sp.Elapsed;
            Console.WriteLine("Sorted array by using insertion sort algorithm");
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i]);
            }
            Console.WriteLine("The count of operations  in insertion sort is" + count);
            Console.WriteLine(ts);
            Console.ReadLine();
        }
    }
}