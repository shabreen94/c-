﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculator
{
   public  class MyExecption : Exception
    {
        public MyExecption(string message)
        {

            Console.WriteLine(message);
            Console.ReadLine();

        }
    }

    class Program 
    {
        static void Main(string[] args)
        {

            int num1 = 0;
            int num2 = 0;
            Console.WriteLine("Enter the  two numbers to perform the arithmetic operation");

                try
                {
                num1 = Convert.ToInt32(Console.ReadLine());
                num2 = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {

                //Console.WriteLine("The enterd values are not in  the correct format");
                throw new MyExecption("Please enter the integers only");
              
                }
            
            
            Displaymenu();
            int choice = GetInt("Enter the choice of operation");
            int result;
            switch (choice)
            {
                case 1: result = Add(num1, num2); break;
                case 2: result = Substract(num1, num2); break;
                case 3: result = Multiply(num1, num2); break;
                case 4: result = Div(num1, num2);


                    break;

            }
        }

        

        private static int GetInt(String message)
        {
            int val = 0;
            while (true)
            {
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.WriteLine("Error! Try again");
            }
            return val;
        }
        private static int Div(int num1, int num2)
        {
            int result = 0;
            try
            {
                result = num1 / num2;
                Console.WriteLine("The result of divide operation is" + result);
                Console.ReadLine();
            }
            catch (DivideByZeroException e) when (num1 == 0 && num2 == 0)
            {

                Console.WriteLine("Both the number are zero so divide operation cannot be performed" + e.Message);

                Console.ReadLine();
            }
            catch (Exception e) when (num2 == 0)
            {
                Console.WriteLine("The second number is zero so divide operation cannot be performed " + e.Message);
                Console.ReadLine();


            }

            return result;
        }
        private static int Substract(int num1, int num2)
        {
            return num1 - num2;
        }

        private static int Multiply(int num1, int num2)
        {
            return num1 * num2;
        }

        private static int Add(int num1, int num2)
        {
            return num1 + num2;
        }

        private static void Displaymenu()
        {
            Console.WriteLine("1. Add");
            Console.WriteLine("2. Sub");
            Console.WriteLine("3. Multiply");
            Console.WriteLine("4. Divide");
        }
    }

    

   
}