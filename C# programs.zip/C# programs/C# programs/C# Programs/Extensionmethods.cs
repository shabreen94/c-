﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extensionmethods
{
   public  static class Extrension
    {
     public  static  void  details(this Employee e)
        {

            Console.WriteLine("Inside the extension method");
            Console.ReadLine();
            e.details();
        }
    }


    class Program
    {
        static void Main(string[] args)
        {

            var  e = new Employee { id = 21, name = "harika" };
            var  e1 = new Employee { id = 21, name = "harika" };

            /*
             To call the extension method even though the instance method is available
             */
            
           Extrension.details(e);

            /*
             To cal the instance method by using the object
             */
            e.details();
            //List<Employee> emps = new List<Employee>();
            //emps.Add(e);
            //emps.Add(e1);
            //emps.details();
        }
    }


  public  class Employee
    {
        public int id;
        public string name;
        public void   details()
        {
            Console.WriteLine("Instance  details method is called");
            Console.ReadLine();

        }

        //public void details()
    }
}
