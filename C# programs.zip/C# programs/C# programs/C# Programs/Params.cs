﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace paramss
{
    //class Test
    //{
    //    static int Sum(params int[] ints)
    //    {
    //        int sum = 0;
    //        for (int i = 0; i < ints.Length; i++)
    //            sum += ints[i]; // Increase sum by ints[i]
    //        return sum;
    //    }
    //    static void Main()
    //    {
    //        // sum(1,2,3,4,5,.........)
    //        //int total = Sum(1, 2, 3, 4);

    //        // As an ordinary array of integers
    //        int total = Sum(new int[] { 1, 2, 3, 4, 5, 6 });
    //        Console.WriteLine(total); // 10
    //        Console.ReadLine();
    //    }
    //}

    class OptionalParams
    {
       
        public void Foo(int y)
        {

            Console.WriteLine("The default value of y "+y);
            Console.ReadLine();

        }

    }

    class Test

    {

        public static void Main(string[] args)
        {
            int x = 23;
            OptionalParams op = new OptionalParams();
            op.Foo(x);


        }



    }


}
