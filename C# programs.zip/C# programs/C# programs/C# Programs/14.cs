﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bankaccount
{
    class Program
    {
        static void Main(string[] args)
        {
            Bank user1 = new Bank();
            user1.intialvalues();
            DisplayMenu();
            Console.WriteLine("Choose the choice of operation");
            int choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    user1.depositamount();
                    break;
                case 2:
                    user1.withdrawamount();
                    break;
            }
        }

        static void DisplayMenu()
        {
            Console.WriteLine("Welcome to the Banking system");
            string[] menu =
            {
                "1.Deposit the amount",
                "2.Withdraw the amount"
            };

            for (int i = 0; i < menu.Length; i++)
            {
                Console.WriteLine(menu[i]);
            }
        }
    }

    class Bank
    {

        public string name;
        public string account_number;
        public string accType;
        public double bal;

        /*Purpose:To set the initial values for the account
         */
        public  void intialvalues()
        {
            Console.WriteLine("Set the values ");
            Console.WriteLine("Enter the name of account holder");
            name = Console.ReadLine();
            Console.WriteLine("Enter the account number");
            account_number = Console.ReadLine();
            Console.WriteLine("Enter the account type");
            accType = Console.ReadLine();
            Console.WriteLine("Enter the amount");
            bal = Convert.ToInt32(Console.ReadLine());
            displayname();
           
        }

        /*Purpose:
         * To deposit the amount in to the bank account*/
        public void depositamount()
        {
           
            Console.WriteLine("Please enter the account number to which the amount is to be deposited");
            string accnumber = Console.ReadLine();

            if (accnumber == account_number)
            {
                Console.WriteLine("Enter the amount to be deposited");
                bal = bal + Convert.ToDouble(Console.ReadLine());
            }

            else
            {
                Console.WriteLine("The account number is not invalid");

            }
            displayname();
            Console.ReadLine();
        }

        /*Purpose:To withdraw the amount from the bank account
         */
        
        public void withdrawamount()
        {
           
            Console.WriteLine("Please enter the account number to which the amount is to be deposited");
            string accnumber = Console.ReadLine();

            if (accnumber == account_number)
            {
                Console.WriteLine("Enter the amount to be withdrawn");
                bal = bal - Convert.ToDouble(Console.ReadLine());
            }

            else
            {
                Console.WriteLine("The account number is not invalid");

            }
            displayname();
            Console.ReadLine();
        }

        /*Purpose:To display the details of the account holder
         */
        public void displayname()
        {
            Console.WriteLine("The bankacoount holder {0} maintaining the balane {1}", name, bal);
        }
    }
}
