﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectionOperattors
{
    class Program
    {
        static void Main(string[] args)
        {

            int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

            //var numsPlusOne =
            //    from n in numbers
            //    select n * n;

            //List<Employee> list = new List<Employee>
            //{
            //    new Employee { id = 1,name = "harika"},
            //    new Employee { id = 2 ,name = "lakshmi"},
            //    new Employee { id = 3,name = "nallagatla"}
            //};

            //var numsPlusOne = from i in list
            //                  where i.id !=2
            //                  select i.name;

           
            string[] strings = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };

            //var textNums =
            //    from n in numbers
            //    select strings[n];

            //var textNums =
            //    from s in strings
            //    select s.ToUpper();

            //Output is ZERO ONE TWO .....

            //var textNums =
            //   from s in strings
            //   select new { Upper = s.ToUpper() };

            //OUTPUT :{Upper = ZERO} {Upper = ONE} {Upper = TWO}


            // Console.WriteLine("Numbers + 1:");
            var textNums =
       from n in numbers
       select new { Digit = strings[n], Even = (n % 2 == 0) };


            foreach (var i in textNums)
            {
                Console.WriteLine(i);
                Console.ReadLine();
                    
            }
        }
    }

    class Employee
    {
        public int id;
        public string name;
    }
}
