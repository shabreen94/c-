﻿using System;
using System.Media;

namespace Selfprintingprogram
{
    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        Console.BackgroundColor = ConsoleColor.Cyan;
    //        Console.Clear();//apply color to the complete window
    //        Console.ForegroundColor = ConsoleColor.Red;
    //        Console.WriteLine("Background color  and foreground color are  changed");
    //        Console.WriteLine(sizeof(int));
    //        Playsound();

    //        Console.ReadLine();
    //    }

    //    public static void Playsound() {
    //        SoundPlayer simplesound = new SoundPlayer(@"C:\Windows\Media\Alarm01.wav");
    //        simplesound.Play();
    //    }
    //}

    class Person
    {
        public static int no;
        public int id;
        public string fname;
        public string lname;

        // Cannot be accesible outside the class
        //Person() or private Person() or protected Person()
        //{
        //}


        public  Person()
        {

            Console.WriteLine("inside the constructor ");
            Console.WriteLine("the size of the integer is " + id.GetType());//will give the type of the datatype like Int32....
            ValueType r = 'c';
            Console.WriteLine(r.GetType());

            //Compiation errors cannot implicitly convert from valuetype to string
            //ValueType d = 'ac';
            //Console.WriteLine(r.GetType());
            //ValueType f = "Hello World";
            //Console.WriteLine(r.GetType());


        }
        public string  getName()
        {
            this.lname = "nallagatla";
            return this.lname;

        }

        //Static block for the static members intiailaisation 
        static Person()
        {
            no = 500340;
            Console.WriteLine("Inside the static constructor" + no);
        }

        //public  void Main1() {
        //Person p4 = new Person { id = 10 * 10, fname = "harika", lname = getname() }; oject is required for a non static field
        //if getname is static use Person.getname will work then lname also should be static member
        //}

    }

    class Test1
    {

        public static void Main(string[] args)
        {

            Person p = new Person();

            // No need to decalre the parametrised construtors declaration

            Person p1 = new Person { id = 1, fname = "lakshmi", lname = "harika" };
            Person p2 = new Person { id = 10 * 10, fname = "harika", lname = "nallagatla" };
           

            // Person p4 = new Person { id = 10 * 10, fname = "harika", lname = getname() };because the getname not exist in the context

            var p3 = new  { id = 5, lname = "hairka" };
           // p3.lname = "hari"; anonymous value s are readonly values
            Console.WriteLine(p.id);
            Console.WriteLine(p1.id);
            Console.WriteLine(p1.ToString());//prints the namespace.classname of object
            Console.WriteLine(p2.id);
            Console.ReadLine();
        }

    }
}
